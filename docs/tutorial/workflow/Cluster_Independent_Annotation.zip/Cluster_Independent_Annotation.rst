CLUSTER INDEPENDENT ANNOTATION
==============================

.. code:: ipython3

    # import required modules
    import numpy as np
    import pandas as pd
    import scanpy as sc
    from cia import investigate, report, utils, external

Index
-----

1. `Introduction <#introduction>`__
2. `CIA input <#CIA-input>`__

   -  `Gene signatures <#Gene-signatures>`__
   -  `AnnData <#AnnData>`__

3. `Signature score <#Signature-score>`__

   -  `Default score <#Default-score>`__
   -  `Scaled score <#Scaled-score>`__

4. `Signature-based classification <#Signature-based-classification>`__

   -  `Default classification <#Default-classification>`__
   -  `Classification with similarity
      threshold <#Classification-with-similarity-threshold>`__

5. `Classification performance
   evaluation <#Classification-performance-evaluation>`__
6. `Tips <#Tips>`__

   -  `Direct inspection of MSigDB
      signatures <#Direct-inspection-of-MSigDB-signatures>`__
   -  `Majority voting <#Majority-voting>`__
   -  `Extraction of signatures from Differentially Expressed
      Genes <#Extraction-of-signatures-from-Differentially-Expressed-Genes>`__

7. `Conclusion <#Conclusion>`__
8. `References <#References>`__

Introduction
------------

**Cluster Independent Annotation** (**CIA**) is a classification method
designed to **assist researchers during the cell annotation step** of
scRNA-seq experiments. Given gene signatures as input, this classifier
**computes a signature score for each cell** and **compares the score
values** to assign a label to each single cell.

This tool offers several advantages:

-  It synthesizes the information of **an entire signature expression
   into a single score value**, avoiding the tedious inspection of
   individual marker genes from lengthy differentially expressed genes
   (DEGs) lists, which may not be cluster-specific individually.
-  It makes possible the exploration of new signatures derived from your
   research for which training data for machine learning algorithms may
   not yet exist.
-  It provides a classification for each cell that is **completely
   independent of clustering**, allowing it to be used alongside a
   clustering method to set a proper resolution value, thus yielding
   coherent and easily annotated cell groups.

-  **It’s very fast**: it can classify a large dataset (hundreds of
   thousands of cells) in just a few seconds since **we have implemented
   the ability to parallelize processes**.

-  Being signature-based, this tool can deliver insights on **any kind
   of biologically meaningful gene list**, also enabling functional
   annotation.

-  By normalizing for the gene signature length, it facilitates the
   **comparison of gene sets of varying lengths**, ranging **from tens
   to thousands of genes**.

In this tutorial we exploited CIA functions to **automatically
annotate**\ `PBMC3K <https://scanpy.readthedocs.io/en/stable/generated/scanpy.datasets.pbmc3k.html>`__\ **scRNA-seq
datasetq** at cellular level, starting from a set of gene signatures
extracted from a `PBMC
atlas <https://www.sciencedirect.com/science/article/pii/S0092867421005833>`__.

.. figure:: attachment:datasets.png
   :alt: datasets.png

   datasets.png

CIA input
---------

Our method requires as input a **dictionary containing the names of the
signatures** (e.g. cell type, cell state …) **as keys and correspondent
gene names as values** and an
`AnnData <https://anndata.readthedocs.io/en/latest/>`__ object with a
**raw expression matrix** (AnnData.raw.X) to be classified.

Gene signatures
~~~~~~~~~~~~~~~

In our study, we used the differentially expressed genes (DEGs) from Hao
et al., 2021’s
`[1] <https://www.sciencedirect.com/science/article/pii/S0092867421005833>`__
**PBMC atlas** as signature markers. The original clusters in this
dataset were annotated using an integrated analysis combining RNA and
protein data, ensuring the **RNA-based gene lists accurately represent
specific cell types**. We focused on the broadest annotation level for
clearer visualization and easier cross-dataset comparison. **We omitted
the ‘other T’** label from our analysis, as it includes cell types not
present in the PBMC3K dataset, making validation impossible. The
**‘other’** cluster, predominantly platelets, **was relabeled as
‘Platelet’** for clarity.

N.B. - DEGs have been filtered to create concise and targeted gene
lists: a log2 fold change greater than 1.5, a minimum average expression
level of 0.25, a z-score above 5, and expression in at least 40% of the
cells within each cluster.

.. code:: ipython3

    # to load the gene signatures
    gmt=investigate.load_signatures('https://raw.githubusercontent.com/ingmbioinfo/cia/master/tutorial/data/atlas.gmt')
    #load_signatures can load both dictionaries or gmt files by providing both file_paths or URLs
    
    for i in gmt.keys():
        print(i+': '+str(len(gmt[i]))+' genes')


.. parsed-literal::

    B: 115 genes
    CD4 T: 43 genes
    CD8 T: 22 genes
    DC: 156 genes
    Mono: 674 genes
    NK: 130 genes
    Platelet: 132 genes


.. code:: ipython3

    # to check gene lists similarity (Jaccard Index)
    utils.signatures_similarity(gmt, show='J')




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>B</th>
          <th>CD4 T</th>
          <th>CD8 T</th>
          <th>DC</th>
          <th>Mono</th>
          <th>NK</th>
          <th>Platelet</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>B</th>
          <td>1.000000</td>
          <td>0.006369</td>
          <td>0.000000</td>
          <td>0.097166</td>
          <td>0.019380</td>
          <td>0.004098</td>
          <td>0.008163</td>
        </tr>
        <tr>
          <th>CD4 T</th>
          <td>0.006369</td>
          <td>1.000000</td>
          <td>0.203704</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
        </tr>
        <tr>
          <th>CD8 T</th>
          <td>0.000000</td>
          <td>0.203704</td>
          <td>1.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.034014</td>
          <td>0.006536</td>
        </tr>
        <tr>
          <th>DC</th>
          <td>0.097166</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>1.000000</td>
          <td>0.080729</td>
          <td>0.007042</td>
          <td>0.014085</td>
        </tr>
        <tr>
          <th>Mono</th>
          <td>0.019380</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.080729</td>
          <td>1.000000</td>
          <td>0.005000</td>
          <td>0.028061</td>
        </tr>
        <tr>
          <th>NK</th>
          <td>0.004098</td>
          <td>0.000000</td>
          <td>0.034014</td>
          <td>0.007042</td>
          <td>0.005000</td>
          <td>1.000000</td>
          <td>0.023438</td>
        </tr>
        <tr>
          <th>Platelet</th>
          <td>0.008163</td>
          <td>0.000000</td>
          <td>0.006536</td>
          <td>0.014085</td>
          <td>0.028061</td>
          <td>0.023438</td>
          <td>1.000000</td>
        </tr>
      </tbody>
    </table>
    </div>



AnnData
~~~~~~~

In order **to evaluate both the consistency** of our method **and the
performances of classification**, **we used** the PMBC atlas **DEGs to
automatically annotate** the
`PBMC3K <https://scanpy.readthedocs.io/en/stable/generated/scanpy.datasets.pbmc3k.html>`__
dataset from *Satija et al., 2015*
`[2] <https://www.nature.com/articles/nbt.3192>`__. This dataset was
annotated by the authors relying on clustering and marker genes
expression inspection and it is widely used as reference in the
scientific community. **We classified** this dataset **independently
from the already present annotation**, whose **cell labels were used as
ground truth** to evaluate our classification perfomances with different
modalities.

With the intent of standardize the analysis, **we strongly suggest** to
use AnnData objects preprocessed following those `Scanpy
tutorial <https://scanpy-tutorials.readthedocs.io/en/latest/pbmc3k.html>`__
steps:

-  **standard filtering** on cells and genes.
-  setting **normalized and logarithmized raw gene expression** values
   as .raw attribute.

.. code:: ipython3

    # to load the test dataset
    pbmc3k=sc.read('data/pbmc3k.h5ad')
    
    # to normalize and logarithmize the values
    sc.pp.normalize_total(pbmc3k, target_sum=1e4)
    sc.pp.log1p(pbmc3k)
    
    # to set the .raw attribute
    pbmc3k.raw=pbmc3k

.. code:: ipython3

    pbmc3k.uns['Cell type_colors']=['#b2df8a', '#fb9a99', '#1f78b4', '#E4D00A', '#6fadfd', '#d62728','#FF5733']

For the classification of the test dataset **we renamed and merged some
clusters** in order to make easier the comparison and the visualization
of results. In particular, ‘CD14+ Monocytes’ and ‘FCGR3A+ Monocytes’
clusters were merged into ‘Mono’.

.. code:: ipython3

    sc.pl.umap(pbmc3k, color=['louvain','Cell type'], wspace=0.6)


.. parsed-literal::

    /mnt/home/ferrari/miniconda414/envs/cia/lib/python3.10/site-packages/scanpy/plotting/_tools/scatterplots.py:392: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(
    /mnt/home/ferrari/miniconda414/envs/cia/lib/python3.10/site-packages/scanpy/plotting/_tools/scatterplots.py:392: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



.. image:: output_21_1.png


Signature score
---------------

The ``compute_signature_scores`` function is **based on the “gene
signature score”** calculation method presented in *Della Chiara,
Gervasoni, Fakiola, Godano et al., 2021*
`[3] <https://www.nature.com/articles/s41467-021-22544-y>`__. The “gene
signature score” of a signature **S** in a cell **C** is defined as
follows:

.. math:: {\bf{GSS(C)}}=\frac{n}{L}\frac{\sum_{i=1}^n {\bf{X}}_i\: for\: {\bf{G}}_i \in S}{\sum_{j=1}^m {\bf{X}}_j\: for\: {\bf{G}}_j \in G}

Where: - **n** is the number of genes in **S** that are expressed in
**C**; - **G** = {𝐺₁, 𝐺₂, …, 𝐺ₘ} is the list of length **m** that
contains all the gene symbols of cell **C**; - **S** = {𝐺₁, 𝐺₂, …, 𝐺ₗ}
is the list of gene symbols of length **L** that compose the signature;
- **X** = {𝑋₁, 𝑋₂, …, 𝑋ₘ} is the vector of gene expression values for
genes in list **G**.

With this score it is possible to **condensate in a single value both
the proportion of expressed signature genes and their overall
expression**, enabling researchers to easily study whole signatures
expression at single cell level.

.. code:: ipython3

    investigate.compute_signature_scores(data=pbmc3k, geneset=gmt['B']) 
    # compute the signature scores of B cells gene signature for each cell




.. parsed-literal::

    array([0.16288456, 2.0365728 , 0.05562652, ..., 2.26067215, 1.52375561,
           0.13641831])



Default score
~~~~~~~~~~~~~

To compute the signature scores of each signature in parallel, we
implemented the ``signature_scores`` function. The function calls
``load_signatures``, allowing it to support both **signature
dictionaries** and canonical **gmt files** (tab separated and without
header), which can be provided as either a **filepath** or a **URL**.

.. code:: ipython3

    investigate.signature_score(data=pbmc3k,signatures_input=gmt, score_mode='raw', return_df=True, n_cpus=32)
    # "raw" is the default score mode, the one indicated as GSS in the formula.


.. parsed-literal::

    Checking if genes are in AnnData.var_names...
    
    B: 101/115
    CD4 T: 40/43
    CD8 T: 20/22
    DC: 151/156
    Mono: 649/674
    NK: 126/130
    Platelet: 123/132 
    




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>CD4 T</th>
          <th>CD8 T</th>
          <th>NK</th>
          <th>DC</th>
          <th>B</th>
          <th>Mono</th>
          <th>Platelet</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>0.212984</td>
          <td>0.133218</td>
          <td>0.795511</td>
          <td>0.101871</td>
          <td>0.162885</td>
          <td>3.586129</td>
          <td>0.289832</td>
        </tr>
        <tr>
          <th>1</th>
          <td>0.040765</td>
          <td>0.009784</td>
          <td>0.446058</td>
          <td>0.989410</td>
          <td>2.036573</td>
          <td>9.018179</td>
          <td>0.728088</td>
        </tr>
        <tr>
          <th>2</th>
          <td>0.423940</td>
          <td>0.058274</td>
          <td>0.447281</td>
          <td>0.093946</td>
          <td>0.055627</td>
          <td>5.277054</td>
          <td>0.555545</td>
        </tr>
        <tr>
          <th>3</th>
          <td>0.003293</td>
          <td>0.003293</td>
          <td>0.397583</td>
          <td>0.960809</td>
          <td>0.304273</td>
          <td>28.666899</td>
          <td>0.743924</td>
        </tr>
        <tr>
          <th>4</th>
          <td>0.015666</td>
          <td>0.064994</td>
          <td>3.622756</td>
          <td>0.312366</td>
          <td>0.045849</td>
          <td>1.749117</td>
          <td>0.305545</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>2633</th>
          <td>0.002645</td>
          <td>0.002645</td>
          <td>0.387395</td>
          <td>2.359434</td>
          <td>0.455459</td>
          <td>38.973505</td>
          <td>0.676382</td>
        </tr>
        <tr>
          <th>2634</th>
          <td>0.072970</td>
          <td>0.000635</td>
          <td>0.282399</td>
          <td>0.449517</td>
          <td>0.677553</td>
          <td>6.725752</td>
          <td>0.539720</td>
        </tr>
        <tr>
          <th>2635</th>
          <td>0.026156</td>
          <td>0.000000</td>
          <td>0.092876</td>
          <td>0.937729</td>
          <td>2.260672</td>
          <td>4.705452</td>
          <td>0.150290</td>
        </tr>
        <tr>
          <th>2636</th>
          <td>0.001920</td>
          <td>0.000000</td>
          <td>0.238040</td>
          <td>0.608006</td>
          <td>1.523756</td>
          <td>3.352826</td>
          <td>0.135530</td>
        </tr>
        <tr>
          <th>2637</th>
          <td>0.350350</td>
          <td>0.066447</td>
          <td>0.131050</td>
          <td>0.117211</td>
          <td>0.136418</td>
          <td>2.486923</td>
          <td>0.693216</td>
        </tr>
      </tbody>
    </table>
    <p>2638 rows × 7 columns</p>
    </div>



**Signature scores are stored by default in AnnData.obs**, adding a
column for each signature, named accordingly to the signature name. With
return_df=True a dataframe is also returned.

Scaled score
~~~~~~~~~~~~

The scaled score is the **GSS divided by the maximum score value**, an
operation that rescales the values from 0 to 1. This allows scaled
scores of **different signatures**, even with **varying lengths**, to be
**directly compared**. To compute the ‘scaled’ score, score_mode must be
set to ‘scaled’.

.. code:: ipython3

    investigate.signature_score(data=pbmc3k, signatures_input=gmt, score_mode='scaled', n_cpus=32)


.. parsed-literal::

    Checking if genes are in AnnData.var_names...
    
    B: 101/115
    CD4 T: 40/43
    CD8 T: 20/22
    DC: 151/156
    Mono: 649/674
    NK: 126/130
    Platelet: 123/132 
    


.. code:: ipython3

    sc.pl.umap(pbmc3k, color='Cell type')


.. parsed-literal::

    /mnt/home/ferrari/miniconda414/envs/cia/lib/python3.10/site-packages/scanpy/plotting/_tools/scatterplots.py:392: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



.. image:: output_33_1.png


By inspecting the score values, for all the signatures, **the highest
values are found in the proper cluster**, indicating the sensitivity of
the signatures and the capability of the signature score to represent
the expression of the whole gene lists.

.. code:: ipython3

    sc.pl.umap(pbmc3k, color=gmt.keys(), color_map='Reds')



.. image:: output_35_0.png


To better viusualize those distributions, we exploited
``grouped_distributions``. By selecting AnnData.obs columns containing
**signature scores**, this function plots **a heatmap showing the
medians of their values in cell groups** and it prints **a statistical
report**. **For each cell group**, a two-sided **Wilcoxon test** is
perfomed to evaluate if the distribution with the highest median is
different from the others. **For each signature**, a two-sided
**Mann-Whitney U test** is performed to evaluate if the distribution in
the cell group having the highest median is different from the other
groups distributions.

.. code:: ipython3

    report.grouped_distributions(pbmc3k, groups_obs='Cell type', columns_obs=['CD4 T', 'B', 'CD8 T', 'NK', 'Mono', 'DC', 'Platelet'],
                                 scale_medians='column-wise', cmap='Reds')


.. parsed-literal::

    /mnt/home/ferrari/dev_cia/cia/src/cia/report.py:87: FutureWarning: The default value of numeric_only in DataFrameGroupBy.median is deprecated. In a future version, numeric_only will default to False. Either specify numeric_only or select only columns which should be valid for the function.
      grouped_df=data.obs.groupby(groups_obs).median()


.. parsed-literal::

    Performing Wilcoxon test on each cell group ...
    WARNING in cell group DC: DC values are not significantly different from Mono values.
    
    Performing Mann-Whitney U test on each selected AnnData.obs column ...
    For each distribution, there is only a cell group in which values are higher with respect to all the other groups  (p<0.01)




.. parsed-literal::

    <Axes: ylabel='Cell type'>




.. image:: output_37_3.png


The statistical tests confirmed that the **visible differences in
signature score distributions are significant**, indicating that scaled
signature scores are consistent with authors annotation. With the
evidence of the goodness of the signatures, we proceeded with the
classification of PBMC3K.

Signature-based classification
------------------------------

To classify the PBMC3K dataset we used
``signature_based_classification``, which directly computes and compares
scaled scores of each signature in each single cell of the dataset

Default classification
~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    %%time
    investigate.signature_based_classification(data=pbmc3k, signatures_input=gmt, similarity_threshold=0, 
                                               label_column='CIA prediction default', n_cpus=32)


.. parsed-literal::

    Checking if genes are in AnnData.var_names...
    
    B: 101/115
    CD4 T: 40/43
    CD8 T: 20/22
    DC: 151/156
    Mono: 649/674
    NK: 126/130
    Platelet: 123/132 
    
    Classification complete! Start time: 09:25:51, End time: 09:25:51, Results stored in AnnData.obs["CIA prediction default"]
    CPU times: user 496 ms, sys: 10.6 ms, total: 507 ms
    Wall time: 352 ms


Classification is performed by **assigning to each cell the label of the
signature that has the maximum scaled score value**. Because it is based
on matrix and vector operations, and given the possibility to
parallelize the computation, this process is **very fast**.

.. code:: ipython3

    pbmc3k.uns['CIA prediction default_colors']=['#fb9a99', '#b2df8a', '#1f78b4', '#d62728', '#6fadfd', '#E4D00A','#FF5733']

.. code:: ipython3

    sc.pl.umap(pbmc3k, color=['Cell type','CIA prediction default'], wspace=0.5)


.. parsed-literal::

    /mnt/home/ferrari/miniconda414/envs/cia/lib/python3.10/site-packages/scanpy/plotting/_tools/scatterplots.py:392: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(
    /mnt/home/ferrari/miniconda414/envs/cia/lib/python3.10/site-packages/scanpy/plotting/_tools/scatterplots.py:392: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



.. image:: output_45_1.png


.. code:: ipython3

    report.group_composition(pbmc3k, classification_obs='CIA prediction default', groups_obs='Cell type',
                      columns_order=['CD4 T', 'B', 'CD8 T', 'NK', 'Mono', 'DC', 'Platelet'], cmap='Greens')




.. parsed-literal::

    <Axes: xlabel='CIA prediction default', ylabel='Cell type'>




.. image:: output_46_1.png


The confusion matrix reveals that the classification method is highly
effective, with most cells being correctly labeled according to their
true cell types. The errors that did occur are relatively few and can be
summarized as follows:

-  **CD4 T cells:** Predominantly classified correctly, with a small
   number misclassified as CD8 T cells.
-  **CD8 T cells:** Mostly identified accurately, but with some
   confusion with NK cells noted.
-  **Dendritic cells:** Generally well-classified, although there is a
   tendency for some cells to be mislabeled as monocytes.

Classification with similarity threshold
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The similarity threshold is a critical parameter in the classification
process, utilized within the ``signature_based_classification``
function. It sets **the minimum required difference between the highest
and second-highest signature scores** for a cell to be confidently
classified into a specific category. This threshold **prevents ambiguous
classifications** and ensures that cells are distinctly assigned to the
most appropriate categories based on their signature expression levels.

Cells whose signature scores do not meet this threshold are labeled as
**‘Unassignned’**. This label indicates that these cells do not exhibit
a strong correlation with any of the predefined signatures, thus
avoiding misclassification.

Here we test 3 tresholds: 5%, 10% and 15%.

.. code:: ipython3

    for t in [0.05, 0.1, 0.15]:
        investigate.signature_based_classification(data=pbmc3k, signatures_input=gmt, similarity_threshold=t, 
                                               label_column='CIA prediction t='+str(t), n_cpus=32)


.. parsed-literal::

    Checking if genes are in AnnData.var_names...
    
    B: 101/115
    CD4 T: 40/43
    CD8 T: 20/22
    DC: 151/156
    Mono: 649/674
    NK: 126/130
    Platelet: 123/132 
    
    Classification complete! Start time: 09:25:52, End time: 09:25:52, Results stored in AnnData.obs["CIA prediction t=0.05"]
    Checking if genes are in AnnData.var_names...
    
    B: 101/115
    CD4 T: 40/43
    CD8 T: 20/22
    DC: 151/156
    Mono: 649/674
    NK: 126/130
    Platelet: 123/132 
    
    Classification complete! Start time: 09:25:52, End time: 09:25:53, Results stored in AnnData.obs["CIA prediction t=0.1"]
    Checking if genes are in AnnData.var_names...
    
    B: 101/115
    CD4 T: 40/43
    CD8 T: 20/22
    DC: 151/156
    Mono: 649/674
    NK: 126/130
    Platelet: 123/132 
    
    Classification complete! Start time: 09:25:53, End time: 09:25:53, Results stored in AnnData.obs["CIA prediction t=0.15"]


.. code:: ipython3

    pbmc3k.uns['CIA prediction t=0.05_colors']=['#fb9a99', '#b2df8a', '#1f78b4', '#d62728', '#6fadfd', '#E4D00A','#FF5733','#808080']
    pbmc3k.uns['CIA prediction t=0.1_colors']=['#fb9a99', '#b2df8a', '#1f78b4', '#d62728', '#6fadfd', '#E4D00A','#FF5733','#808080']
    pbmc3k.uns['CIA prediction t=0.15_colors']=['#fb9a99', '#b2df8a', '#1f78b4', '#d62728', '#6fadfd', '#E4D00A','#FF5733','#808080']

.. code:: ipython3

    sc.pl.umap(pbmc3k, color=['Cell type','CIA prediction default'], wspace=0.5)


.. parsed-literal::

    /mnt/home/ferrari/miniconda414/envs/cia/lib/python3.10/site-packages/scanpy/plotting/_tools/scatterplots.py:392: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(
    /mnt/home/ferrari/miniconda414/envs/cia/lib/python3.10/site-packages/scanpy/plotting/_tools/scatterplots.py:392: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



.. image:: output_53_1.png


.. code:: ipython3

    sc.pl.umap(pbmc3k, color=['CIA prediction t=0.05', 'CIA prediction t=0.1', 'CIA prediction t=0.15'], wspace=0.2)


.. parsed-literal::

    /mnt/home/ferrari/miniconda414/envs/cia/lib/python3.10/site-packages/scanpy/plotting/_tools/scatterplots.py:392: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(
    /mnt/home/ferrari/miniconda414/envs/cia/lib/python3.10/site-packages/scanpy/plotting/_tools/scatterplots.py:392: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(
    /mnt/home/ferrari/miniconda414/envs/cia/lib/python3.10/site-packages/scanpy/plotting/_tools/scatterplots.py:392: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



.. image:: output_54_1.png


Raising the similarity threshold in the classification algorithm indeed
leads to a greater number of cells being labeled as **“Unassigned”**.
This change typically affects **cells that previously might have been
incorrectly classified**, particularly those within groups that exhibit
closely related signature profiles. As the similarity threshold
increases, the classifier becomes more conservative, requiring a higher
degree of confidence before assigning a label. Consequently, **cells
that do not distinctly match a particular signature according to the
stricter criteria are more likely to remain unclassified**.

To further show the importance of this threshold we removed a signature
from the dictionary in order to simulate the situation in which a cell
type of the dataset is not represented by the signatures.

.. code:: ipython3

    del gmt['B'] # B cells signature as been removed

.. code:: ipython3

    for t in [0, 0.1]:
        investigate.signature_based_classification(data=pbmc3k, signatures_input=gmt, similarity_threshold=t, 
                                               label_column='CIA no B t='+str(t), n_cpus=32)


.. parsed-literal::

    Checking if genes are in AnnData.var_names...
    
    CD4 T: 40/43
    CD8 T: 20/22
    DC: 151/156
    Mono: 649/674
    NK: 126/130
    Platelet: 123/132 
    
    Classification complete! Start time: 09:25:54, End time: 09:25:54, Results stored in AnnData.obs["CIA no B t=0"]
    Checking if genes are in AnnData.var_names...
    
    CD4 T: 40/43
    CD8 T: 20/22
    DC: 151/156
    Mono: 649/674
    NK: 126/130
    Platelet: 123/132 
    
    Classification complete! Start time: 09:25:54, End time: 09:25:55, Results stored in AnnData.obs["CIA no B t=0.1"]


.. code:: ipython3

    pbmc3k.uns['CIA no B t=0_colors']=['#b2df8a', '#1f78b4', '#d62728', '#6fadfd', '#E4D00A','#FF5733']
    pbmc3k.uns['CIA no B t=0.1_colors']=[ '#b2df8a', '#1f78b4', '#d62728', '#6fadfd', '#E4D00A','#FF5733','#808080']

.. code:: ipython3

    sc.pl.umap(pbmc3k, color=['CIA no B t=0', 'CIA no B t=0.1'], wspace=0.2)


.. parsed-literal::

    /mnt/home/ferrari/miniconda414/envs/cia/lib/python3.10/site-packages/scanpy/plotting/_tools/scatterplots.py:392: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(
    /mnt/home/ferrari/miniconda414/envs/cia/lib/python3.10/site-packages/scanpy/plotting/_tools/scatterplots.py:392: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



.. image:: output_60_1.png


Indeed, applying a similarity threshold has proven to be a **crucial
step for enhancing the specificity and reliability of the classification
results**. It has effectively reduced the mislabeling of B cells as
Dendritic Cells (DC), demonstrating its value in refining the accuracy
of cell type predictions. Moreover, the threshold’s role in identifying
‘Unassigned’ cells **helps flag potential new or unexpected cell
types**, such as contaminants or previously unidentified cell
populations, within the sample. This feature is especially beneficial
for exploratory analyses where novel discoveries are a possibility.

Classification performance evaluation
-------------------------------------

To evaluate classification performances both per ground truth cluster
and overall we exploited respectively ``grouped_classification_metrics``
and ``classification_metrics`` functions.

In both functions **cell labels assigned by CIA and the annotation
already present in test datasets are compared** in order to count true
positive (TP), true negative (TN), false positive (FP) and false
negative (FN) cells for each cluster. Only for the overall calculation
the per-cluster counts are summed to obtain the total TN, TP, FN and FP.

Then, again for both functions, the following metrics are calculated: -
**Sensitivity** (SE)= TP/(TP+FN) - **Specificity** (SP)= TN/(TN+FP) -
**Precision** (PR)= TP/(TP+FP) - **Accuracy** (ACC)=
(TN+TP)/(TN+TP+FN+FP) - **F1-score** (F1)= 2\ *TP/(2*\ TP+FN+FP)

N.B.: the column of the classification of interest and the one with
ground truth labels must have the same categories to be compared.

Here, for clarity, we show only the **per-cluster classification**
metrics of a single classification.

.. code:: ipython3

    report.grouped_classification_metrics(pbmc3k, classification_obs='CIA prediction default',groups_obs='Cell type')




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>SE</th>
          <th>SP</th>
          <th>PR</th>
          <th>ACC</th>
          <th>F1</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>CD4 T</th>
          <td>0.881119</td>
          <td>0.975904</td>
          <td>0.965517</td>
          <td>0.934799</td>
          <td>0.921389</td>
        </tr>
        <tr>
          <th>B</th>
          <td>0.994152</td>
          <td>0.998258</td>
          <td>0.988372</td>
          <td>0.997726</td>
          <td>0.991254</td>
        </tr>
        <tr>
          <th>CD8 T</th>
          <td>0.813291</td>
          <td>0.943583</td>
          <td>0.662371</td>
          <td>0.927976</td>
          <td>0.730114</td>
        </tr>
        <tr>
          <th>NK</th>
          <td>0.941558</td>
          <td>0.989936</td>
          <td>0.852941</td>
          <td>0.987111</td>
          <td>0.895062</td>
        </tr>
        <tr>
          <th>Mono</th>
          <td>0.998413</td>
          <td>0.988546</td>
          <td>0.964724</td>
          <td>0.990902</td>
          <td>0.981279</td>
        </tr>
        <tr>
          <th>DC</th>
          <td>0.675676</td>
          <td>0.998847</td>
          <td>0.892857</td>
          <td>0.994314</td>
          <td>0.769231</td>
        </tr>
        <tr>
          <th>Platelet</th>
          <td>0.800000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>0.998863</td>
          <td>0.888889</td>
        </tr>
      </tbody>
    </table>
    </div>



And here are reported the **overall perfomances of each classification
modality**:

.. code:: ipython3

    report.classification_metrics(pbmc3k, 
                           classification_obs=['CIA prediction default', 'CIA prediction t=0.05', 'CIA prediction t=0.1', 
                                               'CIA prediction t=0.15','CIA no B t=0', 'CIA no B t=0.1'], groups_obs='Cell type')




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>SE</th>
          <th>SP</th>
          <th>PR</th>
          <th>ACC</th>
          <th>F1</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>CIA prediction default</th>
          <td>0.915845</td>
          <td>0.985974</td>
          <td>0.915845</td>
          <td>0.975956</td>
          <td>0.915845</td>
        </tr>
        <tr>
          <th>CIA prediction t=0.05</th>
          <td>0.871114</td>
          <td>0.990081</td>
          <td>0.936049</td>
          <td>0.973086</td>
          <td>0.902415</td>
        </tr>
        <tr>
          <th>CIA prediction t=0.1</th>
          <td>0.803260</td>
          <td>0.993240</td>
          <td>0.951932</td>
          <td>0.966100</td>
          <td>0.871299</td>
        </tr>
        <tr>
          <th>CIA prediction t=0.15</th>
          <td>0.736164</td>
          <td>0.994946</td>
          <td>0.960435</td>
          <td>0.957977</td>
          <td>0.833476</td>
        </tr>
        <tr>
          <th>CIA no B t=0</th>
          <td>0.787339</td>
          <td>0.964556</td>
          <td>0.787339</td>
          <td>0.939240</td>
          <td>0.787339</td>
        </tr>
        <tr>
          <th>CIA no B t=0.1</th>
          <td>0.678923</td>
          <td>0.991218</td>
          <td>0.927979</td>
          <td>0.946605</td>
          <td>0.784151</td>
        </tr>
      </tbody>
    </table>
    </div>



As the similarity threshold is raised, **overall classification
performance may decrease due to an increase in the number of
‘Unassigned’ cells**, which are counted as misclassified. However, **by
setting the unassigned_label, we can exclude ‘Unassigned’ cells from
performance metrics calculations**, thereby refining our analysis.
Consequently, a new column indicating the percentage of unlabeled cells
will be included in the output, providing additional insight into the
classification process.

.. code:: ipython3

    report.classification_metrics(pbmc3k, classification_obs=['CIA prediction default', 'CIA prediction t=0.05',
                                                              'CIA prediction t=0.1', 'CIA prediction t=0.15',
                                                              'CIA no B t=0', 'CIA no B t=0.1'],
                                  unassigned_label='Unassigned', groups_obs='Cell type')




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>SE</th>
          <th>SP</th>
          <th>PR</th>
          <th>ACC</th>
          <th>F1</th>
          <th>%UN</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>CIA prediction default</th>
          <td>0.915845</td>
          <td>0.985974</td>
          <td>0.915845</td>
          <td>0.975956</td>
          <td>0.915845</td>
          <td>0.00</td>
        </tr>
        <tr>
          <th>CIA prediction t=0.05</th>
          <td>0.936049</td>
          <td>0.989341</td>
          <td>0.936049</td>
          <td>0.981728</td>
          <td>0.936049</td>
          <td>6.94</td>
        </tr>
        <tr>
          <th>CIA prediction t=0.1</th>
          <td>0.951932</td>
          <td>0.991989</td>
          <td>0.951932</td>
          <td>0.986266</td>
          <td>0.951932</td>
          <td>15.62</td>
        </tr>
        <tr>
          <th>CIA prediction t=0.15</th>
          <td>0.960435</td>
          <td>0.993406</td>
          <td>0.960435</td>
          <td>0.988696</td>
          <td>0.960435</td>
          <td>23.35</td>
        </tr>
        <tr>
          <th>CIA no B t=0</th>
          <td>0.787339</td>
          <td>0.964556</td>
          <td>0.787339</td>
          <td>0.939240</td>
          <td>0.787339</td>
          <td>0.00</td>
        </tr>
        <tr>
          <th>CIA no B t=0.1</th>
          <td>0.927979</td>
          <td>0.987997</td>
          <td>0.927979</td>
          <td>0.979423</td>
          <td>0.927979</td>
          <td>26.84</td>
        </tr>
      </tbody>
    </table>
    </div>



Tips
----

Direct inspection of MSigDB signatures
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

With the ``signature_score`` function, you can compute and inspect
signatures from the
`MSigDB <https://www.gsea-msigdb.org/gsea/msigdb/>`__ by simply
providing the corresponding URL.

.. code:: ipython3

    investigate.signature_score(data=pbmc3k, signatures_input='https://www.gsea-msigdb.org/gsea/msigdb/human/download_geneset.jsp?geneSetName=GOBP_PHAGOCYTOSIS&fileType=gmt',
                                score_mode='scaled', n_cpus=32)
    sc.pl.umap(pbmc3k, color='GOBP_PHAGOCYTOSIS', color_map='Reds')


.. parsed-literal::

    Checking if genes are in AnnData.var_names...
    
    GOBP_PHAGOCYTOSIS: 175/238 
    



.. image:: output_74_1.png


Majority voting
~~~~~~~~~~~~~~~

The **Celltypist** classifier
`[4] <https://www.science.org/doi/10.1126/science.abl5197>`__ features
an intriguing process called **‘majority voting,’** which refines cell
identities within subclusters following an **over-clustering step**. In
essence, **within each subcluster**, the **label of the predominant cell
type is applied** to all cells in that group. While this step extends
beyond the standard CIA workflow, we aimed to compare classification
results under optimal conditions. To this end, we developed the
``celltypist_majority_vote`` function (**external module**) to emulate
the ‘majority voting’ mechanism.

.. code:: ipython3

    colnames=['CIA prediction default', 'CIA prediction t=0.1']
    external.celltypist_majority_vote(pbmc3k,classification_obs=colnames)


.. parsed-literal::

    Reference annotation not selected. Computing over-clustering with Leiden algorithm (resolution=5) ...
    Dataset has been divided into 69 groups according to transcriptional similarities.
    Over-clustering result saved in AnnData.obs["leiden_5"].
    Extending the more represented cell type label to each cell group...
    
    New classification labels have been stored in AnnData.obs["CIA prediction default_majority_voting"].
    New classification labels have been stored in AnnData.obs["CIA prediction t=0.1_majority_voting"].


.. code:: ipython3

    sc.pl.umap(pbmc3k, color='leiden_5')


.. parsed-literal::

    /mnt/home/ferrari/miniconda414/envs/cia/lib/python3.10/site-packages/scanpy/plotting/_tools/scatterplots.py:392: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



.. image:: output_78_1.png


.. code:: ipython3

    colnames_mv=[c+'_majority_voting' for c in colnames]
    pbmc3k.uns['CIA prediction default_majority_voting_colors']=['#fb9a99', '#b2df8a', '#1f78b4', '#d62728', 
                                                                 '#6fadfd', '#E4D00A','#FF5733']
    pbmc3k.uns['CIA prediction t=0.1_majority_voting_colors']=['#fb9a99', '#b2df8a', '#1f78b4', '#d62728', 
                                                               '#6fadfd', '#E4D00A','#FF5733','#808080']
    sc.pl.umap(pbmc3k, color=colnames_mv)


.. parsed-literal::

    /mnt/home/ferrari/miniconda414/envs/cia/lib/python3.10/site-packages/scanpy/plotting/_tools/scatterplots.py:392: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(
    /mnt/home/ferrari/miniconda414/envs/cia/lib/python3.10/site-packages/scanpy/plotting/_tools/scatterplots.py:392: UserWarning: No data for colormapping provided via 'c'. Parameters 'cmap' will be ignored
      cax = scatter(



.. image:: output_79_1.png


.. code:: ipython3

    report.classification_metrics(pbmc3k, classification_obs=colnames_mv,
                                  unassigned_label='Unassigned', groups_obs='Cell type')




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>SE</th>
          <th>SP</th>
          <th>PR</th>
          <th>ACC</th>
          <th>F1</th>
          <th>%UN</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>CIA prediction default_majority_voting</th>
          <td>0.967779</td>
          <td>0.994630</td>
          <td>0.967779</td>
          <td>0.990794</td>
          <td>0.967779</td>
          <td>0.0</td>
        </tr>
        <tr>
          <th>CIA prediction t=0.1_majority_voting</th>
          <td>0.967138</td>
          <td>0.994523</td>
          <td>0.967138</td>
          <td>0.990611</td>
          <td>0.967138</td>
          <td>0.8</td>
        </tr>
      </tbody>
    </table>
    </div>



Extraction of signatures from Differentially Expressed Genes
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

If you have a dataset from which **you want to extract signatures** for
use with CIA to classify other datasets, **you can use the**
``filter_degs`` function. This function filters differentially expressed
genes (DEGs) obtained with ``scanpy.tl.rank_genes_groups`` based on
specified thresholds. For instance, in the example provided, the
thresholds include a log2 fold change greater than 1, a minimum average
expression level of 0.2, a z-score above 5, and expression in at least
30% of the cells within each cluster.

.. code:: ipython3

    sc.tl.rank_genes_groups(pbmc3k, groupby='louvain')
    gmt=utils.filter_degs(pbmc3k, groupby='louvain', uns_key='rank_genes_groups', logFC=1,  scores=5, perc=30,
                    mean=0.20, direction='up')
    for i in gmt.keys():
        print(i + ' signature has '+ str(len(gmt[i])) +' genes')


.. parsed-literal::

    WARNING: Default of the method has been changed to 't-test' from 't-test_overestim_var'
    CD4 T cells signature has 68 genes
    CD14+ Monocytes signature has 228 genes
    B cells signature has 45 genes
    CD8 T cells signature has 40 genes
    NK cells signature has 125 genes
    FCGR3A+ Monocytes signature has 392 genes
    Dendritic cells signature has 100 genes
    Megakaryocytes signature has 47 genes


Using the ``save_gmt`` function, you can convert a dictionary of
signatures into a gmt file that is correctly formatted for the
``signature_score`` and ``signature_based_classification`` functions.

.. code:: ipython3

    utils.save_gmt(gmt, './data/pbmc3k_sig.gmt')

Conclusion
==========

In this notebook, we have showed the robustness and versatility of the
**Cluster Independent Annotation (CIA)** method. Through the computation
of signature scores and subsequent cell classification, **CIA provides a
fast and efficient approach to cell type annotation in single-cell RNA
sequencing data**. Additionally, we have shown that by increasing the
similarity threshold, CIA can effectively mitigate misclassifications,
illuminating the presence of ambiguous or novel cell types.

References
==========

1. Hao, Y., et al. (2021). Integrated analysis of multimodal single-cell
   data. *Cell*, 184(13), 3573-3587.e29.
   https://www.sciencedirect.com/science/article/pii/S0092867421005833

2. Satija, R., Farrell, J. A., Gennert, D., Schier, A. F., & Regev, A.
   (2015). Spatial reconstruction of single-cell gene expression data.
   *Nature Biotechnology*, 33, 495–502.
   https://www.nature.com/articles/nbt.3192

3. Della Chiara, G., et al. (2021). Gene signature extraction and cell
   identity recognition at the single-cell level with Cell ID. *Nature
   Communications*, 12, 2262.
   https://www.nature.com/articles/s41467-021-22544-y

4. Celltypist Classifier. (2022). Cell type annotation for single-cell
   RNA-seq data with CellTypist. *Science*, 374, eabj8222.
   https://www.science.org/doi/10.1126/science.abl5197
